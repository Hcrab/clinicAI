// src/app/map/page.jsx
"use client";
import { useState } from "react";
import { MapContainer, TileLayer, Marker, useMap } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

// Fix Leaflet default icon issue
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

function MapUpdater({ center }) {
  const map = useMap();
  map.setView(center, center[0] === 0 && center[1] === 0 ? 2 : 10);
  return null;
}

export default function MapPage() {
  const [coordinates, setCoordinates] = useState([0, 0]);
  const [inputLat, setInputLat] = useState("");
  const [inputLng, setInputLng] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    const lat = parseFloat(inputLat);
    const lng = parseFloat(inputLng);

    if (
      isNaN(lat) ||
      isNaN(lng) ||
      lat < -90 ||
      lat > 90 ||
      lng < -180 ||
      lng > 180
    ) {
      setError("Please enter valid coordinates (Lat: -90 to 90, Lng: -180 to 180)");
      return;
    }

    setCoordinates([lat, lng]);
    setError("");
  };

  return (
    <div className="map-container">
      <h1>World Map</h1>
      <p>Enter coordinates to mark a location on the map.</p>

      <form onSubmit={handleSubmit} className="map-input-form">
        <input
          type="text"
          value={inputLat}
          onChange={(e) => setInputLat(e.target.value)}
          placeholder="Latitude (-90 to 90)"
          className="map-input"
        />
        <input
          type="text"
          value={inputLng}
          onChange={(e) => setInputLng(e.target.value)}
          placeholder="Longitude (-180 to 180)"
          className="map-input"
        />
        <button type="submit" className="map-submit-btn">
          Show Location
        </button>
      </form>

      {error && <p className="map-error">{error}</p>}

      <MapContainer
        center={coordinates}
        zoom={coordinates[0] === 0 && coordinates[1] === 0 ? 2 : 10}
        style={{ height: "500px", width: "100%" }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        <MapUpdater center={coordinates} />
        {coordinates[0] !== 0 || coordinates[1] !== 0 ? (
          <Marker position={coordinates} />
        ) : null}
      </MapContainer>
    </div>
  );
}