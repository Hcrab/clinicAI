// src/app/layout.jsx
import "./globals.css";

export const metadata = {
  title: "My Chatbot App",
  description: "A chatbot and map app built with Next.js",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}