// src/app/api/chat/route.js
import { NextResponse } from "next/server";

export async function POST(request) {
  try {
    const { question } = await request.json();

    if (!question) {
      return NextResponse.json({ error: "No question provided" }, { status: 400 });
    }

    // Simple static response logic (replace with AI integration later)
    let answer;
    switch (question.toLowerCase().trim()) {
      case "hello":
        answer = "Hi there! How can I help you today?";
        break;
      case "what is next.js?":
        answer = "Next.js is a React framework for building server-rendered and static web applications.";
        break;
      default:
        answer = "Hmm, I'm not sure about that. Try asking something else!";
    }

    return NextResponse.json({ answer });
  } catch (error) {
    console.error("Chat error:", error);
    return NextResponse.json({ error: "Failed to process request" }, { status: 500 });
  }
}

// When acquire api key:
// import { NextResponse } from "next/server";

// export async function POST(request) {
//   const { question } = await request.json();
//   const res = await fetch("https://api.openai.com/v1/chat/completions", {
//     method: "POST",
//     headers: {
//       "Content-Type": "application/json",
//       Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
//     },
//     body: JSON.stringify({
//       model: "gpt-3.5-turbo",
//       messages: [{ role: "user", content: question }],
//     }),
//   });
//   const data = await res.json();
//   const answer = data.choices[0].message.content;
//   return NextResponse.json({ answer });
// }