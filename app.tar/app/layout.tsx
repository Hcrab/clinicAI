import "./globals.css";
import { ReactNode } from "react"; // 導入 ReactNode 類型

export const metadata = {
  title: "My Chatbot App",
  description: "A chatbot and map app built with Next.js",
};

// 為 children 添加類型
export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}