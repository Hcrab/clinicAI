// src/app/page.jsx
'use client';
import Link from "next/link";

export default function Home() {
  return (
    <div className="container">
      <h1>Welcome to My App</h1>
      <p>Choose a feature:</p>
      <ul>
        <li>
          <Link href="/chatbot">Chatbot</Link>
        </li>
        <li>
          <Link href="/map">World Map</Link>
        </li>
      </ul>
      <style jsx>{`
        .container {
          max-width: 800px;
          margin: 0 auto;
          padding: 20px;
        }
        ul {
          list-style: none;
          padding: 0;
        }
        li {
          margin: 10px 0;
        }
        a {
          color: #0070f3;
          text-decoration: none;
        }
        a:hover {
          text-decoration: underline;
        }
      `}</style>
    </div>
  );
}