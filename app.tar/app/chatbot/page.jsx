// src/app/chatbot/page.jsx
"use client";
import { useState } from "react";

export default function Chatbot() {
  const [question, setQuestion] = useState("");
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!question.trim()) return;

    // Add user's question to messages
    setMessages((prev) => [...prev, { sender: "user", text: question }]);
    setIsLoading(true);

    try {
      // Send question to API
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question }),
      });

      if (!response.ok) throw new Error("Failed to get response");

      const data = await response.json();
      // Add chatbot response to messages
      setMessages((prev) => [...prev, { sender: "bot", text: data.answer }]);
    } catch (error) {
      setMessages((prev) => [
        ...prev,
        { sender: "bot", text: `Error: ${error.message}` },
      ]);
    } finally {
      setIsLoading(false);
      setQuestion(""); // Clear input
    }
  };

  return (
    <div className="container">
      <h1>Chatbot</h1>
      <p>Ask me anything!</p>

      <div className="chat-window">
        {messages.map((msg, index) => (
          <div
            key={index}
            className={`message ${msg.sender === "user" ? "user" : "bot"}`}
          >
            {msg.text}
          </div>
        ))}
        {isLoading && <div className="message bot">Thinking...</div>}
      </div>

      <form onSubmit={handleSubmit} className="input-form">
        <input
          type="text"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="Type your question here..."
          disabled={isLoading}
          className="input"
        />
        <button type="submit" disabled={isLoading} className="submit-btn">
          {isLoading ? "Sending..." : "Ask"}
        </button>
      </form>

      <style jsx>{`
        .container {
          max-width: 800px;
          margin: 0 auto;
          padding: 20px;
        }
        .chat-window {
          min-height: 300px;
          max-height: 500px;
          overflow-y: auto;
          border: 1px solid #ccc;
          padding: 10px;
          margin-bottom: 20px;
          background: #f9f9f9;
          border-radius: 4px;
        }
        .message {
          margin: 10px 0;
          padding: 8px 12px;
          border-radius: 4px;
          max-width: 70%;
        }
        .message.user {
          background: #0070f3;
          color: white;
          margin-left: auto;
          text-align: right;
        }
        .message.bot {
          background: #e0e0e0;
          color: black;
        }
        .input-form {
          display: flex;
          gap: 10px;
        }
        .input {
          flex: 1;
          padding: 8px;
          border: 1px solid #ccc;
          border-radius: 4px;
        }
        .submit-btn {
          padding: 8px 16px;
          background: #0070f3;
          color: white;
          border: none;
          border-radius: 4px;
          cursor: pointer;
        }
        .submit-btn:disabled {
          background: #ccc;
          cursor: not-allowed;
        }
      `}</style>
    </div>
  );
}