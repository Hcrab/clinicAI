"use client";
import { useState, useEffect } from "react";
import dynamic from "next/dynamic";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// 動態導入 MapContainer 等組件，並禁用 SSR
const MapContainer = dynamic(
  () => import("react-leaflet").then((mod) => mod.MapContainer),
  { ssr: false }
);
const TileLayer = dynamic(
  () => import("react-leaflet").then((mod) => mod.TileLayer),
  { ssr: false }
);
const Marker = dynamic(
  () => import("react-leaflet").then((mod) => mod.Marker),
  { ssr: false }
);
const Popup = dynamic(
  () => import("react-leaflet").then((mod) => mod.Popup),
  { ssr: false }
);

// 修復 Leaflet 默認圖標問題
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

export default function MapPage() {
  const [clinics, setClinics] = useState([]); // 存儲診所數據
  const [mapCenter] = useState([22.3193, 114.1694]); // 香港的經緯度

  // 加載診所數據
  useEffect(() => {
    fetch("/clinic_data.json") // 從 public 目錄加載 JSON 文件
      .then((response) => response.json())
      .then((data) => setClinics(data))
      .catch((error) => console.error("Failed to load clinic data:", error));
  }, []);

  return (
    <div className="map-container">
      <h1>香港診所地圖</h1>
      <p>點擊地圖上的大頭針查看診所信息。</p>

      <MapContainer
        center={mapCenter}
        zoom={12}
        style={{ height: "500px", width: "100%" }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />

        {/* 顯示所有診所的大頭針 */}
        {clinics.map((clinic) => (
          <Marker
            key={clinic.clinic_id}
            position={[parseFloat(clinic.latitude), parseFloat(clinic.longitude)]}
          >
            {/* 點擊大頭針顯示診所信息 */}
            <Popup>
              <div>
                <h3>{clinic.name}</h3>
                <p>地址: {clinic.address}</p>
                <p>電話: {clinic.phone}</p>
                <h4>醫生列表:</h4>
                <ul>
                  {clinic.doctors.map((doctor, index) => (
                    <li key={index}>
                      {doctor.name} - {doctor.specialty}
                    </li>
                  ))}
                </ul>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}